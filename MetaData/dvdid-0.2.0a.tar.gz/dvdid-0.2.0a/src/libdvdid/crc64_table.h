/* $Id: crc64_table.h 1421 2009-03-17 11:59:03Z chris $ */

#ifndef DVDID__CRC64_TABLE_H
#define DVDID__CRC64_TABLE_H
#include <stdint.h>

extern const uint64_t crc64_table[];

#endif
